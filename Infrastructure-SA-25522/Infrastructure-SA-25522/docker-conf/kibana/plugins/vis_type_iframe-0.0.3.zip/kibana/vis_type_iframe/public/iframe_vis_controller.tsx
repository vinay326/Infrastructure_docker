
import React from 'react';
import { Iframe } from '../../kibana_react/public';
import { IframeVisParams } from './types';

interface IframeVisComponentProps extends IframeVisParams {
  renderComplete: () => {};
}

/**
 * The IframeVisComponent renders iframe.
 */
class IframeVisComponent extends React.Component<IframeVisComponentProps> {
  /**
   * Will be called after the first render when the component is present in the DOM.
   *
   * We call renderComplete here, to signal, that we are done with rendering.
   */
  componentDidMount() {
    this.props.renderComplete();
  }

  /**
   * Will be called after the component has been updated and the changes has been
   * flushed into the DOM.
   *
   * We will use this to signal that we are done rendering by calling the
   * renderComplete property.
   */
  componentDidUpdate() {
    this.props.renderComplete();
  }

  /**
   * Render the actual HTML.
   */
  render() {
    return (
      <div className="iframeVis">
        {this.props.url ? (
          <iframe
            data-test-subj="iframe"
            src={this.props.url}
          />
        ) : (
          <span>No URL defined.</span>
        )}
      </div>
    );
  }
}

/**
 * This is a wrapper component, that is actually used as the visualization.
 * The sole purpose of this component is to extract all required parameters from
 * the properties and pass them down as separate properties to the actual component.
 * That way the actual (IframeVisComponent) will properly trigger it's prop update
 * callback (componentWillReceiveProps) if one of these params change. It wouldn't
 * trigger otherwise (e.g. it doesn't for this wrapper), since it only triggers
 * if the reference to the prop changes (in this case the reference to vis).
 *
 * The way React works, this wrapper nearly brings no overhead, but allows us
 * to use proper lifecycle methods in the actual component.
 */
export function IframeVisWrapper(props: any) {
  return (
    <IframeVisComponent
      url={props.visParams.url}
      renderComplete={props.renderComplete}
    />
  );
}
