
import React, { useCallback } from 'react';
import {
  EuiPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiFieldText,
} from '@elastic/eui';
import { FormattedMessage } from '@kbn/i18n/react';

import { VisOptionsProps } from 'src/plugins/vis_default_editor/public';
import { IframeVisParams } from  './types';

function IframeOptions({ stateParams, setValue }: VisOptionsProps<IframeVisParams>) {
  const onUpdate = useCallback(
    (value: IframeVisParams['url']) => setValue('url', value),
    [setValue]
  );

  return (
    <EuiPanel paddingSize="s">
      <EuiFlexGroup gutterSize="xs">
        <EuiFlexItem>
          <EuiFieldText
            onChange={({ target: { value } }) => onUpdate(value)}
            value={stateParams.url}
            placeholder="http://w..."
          />
        </EuiFlexItem>
      </EuiFlexGroup>
    </EuiPanel>
  );
}

export { IframeOptions };
