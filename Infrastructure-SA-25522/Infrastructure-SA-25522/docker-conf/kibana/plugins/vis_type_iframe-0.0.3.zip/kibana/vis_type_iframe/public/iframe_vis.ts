
import { i18n } from '@kbn/i18n';

import { IframeVisWrapper } from './iframe_vis_controller';
import { IframeOptions } from './iframe_options';

export const iframeVisDefinition = {
  name: 'iframe',
  title: 'Iframe',
  isAccessible: true,
  icon: 'nested',
  description: i18n.translate('visTypeIframe.iframeDescription', {
    defaultMessage: 'Embed an iframe',
  }),
  visConfig: {
    component: IframeVisWrapper,
    defaults: {
      url: 'http://davecstone.com',
    },
  },
  editorConfig: {
    optionTabs: [
      {
        name: 'options',
        title: i18n.translate('visTypeMarkdown.tabs.optionsText', {
          defaultMessage: 'Options',
        }),
        editor: IframeOptions,
      },
    ],
  },
  options: {
    showTimePicker: false,
    showFilterBar: false,
  },
  requestHandler: 'none',
  responseHandler: 'none',
};
