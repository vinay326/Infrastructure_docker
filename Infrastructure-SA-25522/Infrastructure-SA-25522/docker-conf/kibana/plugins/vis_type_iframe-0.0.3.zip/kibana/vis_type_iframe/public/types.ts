
export interface Arguments {
  url: string;
}

export interface IframeVisParams {
  url: Arguments['url'];
}
