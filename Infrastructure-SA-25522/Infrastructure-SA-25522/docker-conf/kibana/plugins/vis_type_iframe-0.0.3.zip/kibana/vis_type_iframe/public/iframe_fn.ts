
import { i18n } from '@kbn/i18n';
import { ExpressionFunctionDefinition, Render } from '../../expressions/public';
import { Arguments, IframeVisParams } from './types';

interface RenderValue {
  visType: 'iframe';
  visConfig: IframeVisParams;
}

export const createIframeVisFn = (): ExpressionFunctionDefinition<
  'iframeVis',
  unknown,
  Arguments,
  Render<RenderValue>
> => ({
  name: 'iframeVis',
  type: 'render',
  inputTypes: [],
  help: i18n.translate('visTypeIframe.function.help', {
    defaultMessage: 'Iframe visualization',
  }),
  args: {
    url: {
      types: ['string'],
      aliases: ['_'],
      required: true,
      help: i18n.translate('visTypeIframe.function.iframe.help', {
        defaultMessage: 'URL to render',
      }),
    },
  },
  fn(input, args) {
    return {
      type: 'render',
      as: 'visualization',
      value: {
        visType: 'iframe',
        visConfig: {
          url: args.url,
        },
      },
    };
  },
});
