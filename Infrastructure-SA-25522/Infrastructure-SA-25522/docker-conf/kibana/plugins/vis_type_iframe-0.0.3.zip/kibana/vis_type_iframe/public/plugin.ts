
import { CoreSetup, CoreStart, Plugin } from '../../../core/public';
import { Plugin as ExpressionsPublicPlugin } from '../../expressions/public';
import { VisualizationsSetup } from '../../visualizations/public';

import { iframeVisDefinition } from './iframe_vis';
import { createIframeVisFn } from './iframe_fn';

import './index.scss';

/** @internal */
export interface IframePluginSetupDependencies {
  expressions: ReturnType<ExpressionsPublicPlugin['setup']>;
  visualizations: VisualizationsSetup;
}

/** @internal */
export class IframePlugin implements Plugin<void, void> {
  public setup(core: CoreSetup, { expressions, visualizations }: IframePluginSetupDependencies) {
    visualizations.createReactVisualization(iframeVisDefinition);
    expressions.registerFunction(createIframeVisFn);
  }

  public start(core: CoreStart) {
    // nothing to do here yet
  }
}
