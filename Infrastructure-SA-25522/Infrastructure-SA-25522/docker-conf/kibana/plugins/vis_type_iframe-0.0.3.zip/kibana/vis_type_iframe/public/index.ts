
import { PluginInitializerContext } from '../../../core/public';
import { IframePlugin as Plugin } from './plugin';

export function plugin(initializerContext: PluginInitializerContext) {
  return new Plugin(initializerContext);
}
